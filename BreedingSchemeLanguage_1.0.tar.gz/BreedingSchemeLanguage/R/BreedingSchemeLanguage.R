#' BreedingSchemeLanguage
#' 
#' Describe and simulate breeding schemes
#' 
#' @name BreedingSchemeLanguage
#' @docType package
#' @import snowfall Rcpp rrBLUP ggplot2
NULL